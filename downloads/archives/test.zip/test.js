const a = {a: 1, b:2 , c:3};
const b = {a: 1, b:3, c: 4};

console.log('12312'.split(''))